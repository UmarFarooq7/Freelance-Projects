/*
 * MasterMind: a cut down version with just the master-mind game logic (purely C) and no external devices

Sample run:
Contents of the sequence (of length 3):  2 1 1
Input seq (len 3): 1 2 3
0 2
Input seq (len 3): 3 2 1
1 1
Input seq (len 3): 2 1 1
3 0
SUCCESS after 3 iterations; secret sequence is  2 1 1

 * Compile:    gcc -o cw3  master-mind-terminal.c
 * Run:        ./cw3

 */
/*___________Daniel Achineke Marcus_________________H00319971__________________*/
/* --------------------------------------------------------------------------- */

/* Library headers from libc functions */
#include <stdio.h>
#include <conio.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include  <time.h>
/* Constants */
#define  COL  3
#define  LEN  3

/* Global variables */

static const int colors = COL;
static const int seqlen = LEN;
/*total Colors*/
static char* color_names[] = { "red", "green", "blue" };
/*variable for Corresponding sequence of numbers*/
static int theSeq[3] = {0,0,0};
static int match;
static int almost;
//static int guesses;
/* Aux functions */

/* initialise the secret sequence; by default it should be a random sequence, with -s use that sequence */
void initSeq() {
  srand(time(0));
    /*Creating 3 numbered random key Automatically
    1:Red 2:Green 3:Blue*/
    int i=0,keys;
    while(i<3){
        /*We can set the random limit upto any number 
        but here we set the random number should be under 3.*/
        keys=rand()%4;
        /*excluding zero from random sequence*/
        if(keys!=0){
            theSeq[i]=keys;
            i++;
        }
    }
}

/* display the sequence on the terminal window, using the format from the sample run above */
void showSeq(int *seq) {
    /*displaying the random sequence*/
    printf("Contents of the sequence (of length 3): %d %d %d \n",seq[0],seq[1],seq[2]);
}

/* counts how many entries in seq2 match entries in seq1 */
/* returns exact and approximate matches  */
//seq 1 master ;seq2 guess
int countMatches(int *seq1, int *seq2) {
    match = 0;
    almost = 0;
    int flag[3]={0,0,0};
    /*counting the number of exact matches*/
    for(int n=0; n<seqlen; n++ ){
        if(seq1[n]==seq2[n]){
            flag[n]=1;
            match++;
        }
    }
    /*counting the numbers which are present in both the guess and master key but not at the Corresponding place.*/   
    for(int n=0; n<seqlen; n++ ){
        for(int i=0; i<seqlen;  i++){
            if( seq2[n]==seq1[i] && flag[n]==0){
                flag[n]=1;
                almost++;
            }
        }
    }
}

/* show the results from calling countMatches on seq1 and seq1 */
void showMatches(int code, int * seq1, int *seq2) {
    printf(" Matches = %d, Almost =  %d\n", match, almost );
}

/* read a guess sequence fron stdin and store the values in arr */
void readString(int *arr) {
    char  guess[8]={0x00};
    printf("Input Seq (len 3) :");
    fgets(guess,  8,stdin); 
    /*After reading the string, converting the character digits into integer values.
    and saving in integer array*/
    arr[0]=guess[0]-'0';
    arr[1]=guess[2]-'0';
    arr[2]=guess[4]-'0';
}

/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

int main(int argc, char **argv){
  /* DEFINE your variables here */
  int arr[3];
  int found = 0, attempts = 0, b ;
  char ch;
  /* for getopts() command line processing */
  int verbose = 0, help = 0, unittest = 0, debug = 0;
  char *sseq = NULL;
    
  // see: man 3 getopt for docu and an example of command line parsing
  // Use this template to process command line options and to store the input
  {
    int opt;
    while ((opt = getopt(argc, argv, "vuds:")) != -1) {
      switch (opt) {
      case 'v':
	verbose = 1;
	break;
      case 'u':
	unittest = 1;
	break;
      case 'd':
	debug = 1;
	break;
      case 's':
	sseq = (char *)malloc(LEN*sizeof(char));
	strcpy(sseq,optarg);
	break;
      default: /* '?' */
	fprintf(stderr, "Usage: %s [-v] [-d] [-s] <secret sequence> [-u] <secret sequence> <guess sequence> \n", argv[0]);
	exit(EXIT_FAILURE);
      }
    }
    if (unittest && optind >= argc) {
      fprintf(stderr, "Expected argument after options\n");
      exit(EXIT_FAILURE);
    }

    if (verbose && unittest) {
      printf("1st argument = %s\n", argv[optind]);
      printf("2nd argument = %s\n", argv[optind+1]);
    }
  }

  if (verbose) {
    fprintf(stdout, "Settings for running the program\n");
    fprintf(stdout, "Verbose is %s\n", (verbose ? "ON" : "OFF"));
    fprintf(stdout, "Debug is %s\n", (debug ? "ON" : "OFF"));
    fprintf(stdout, "Unittest is %s\n", (unittest ? "ON" : "OFF"));
    if (sseq)  fprintf(stdout, "Secret sequence set to %s\n", sseq);
  }

  if (sseq) { // explicitly setting secret sequence
    /* SET the secret sequence here */
  }    
  if (unittest) {
    /* SET secret and guess sequence here */
    /* then run the countMatches function and show the result */
    
    /* for now just terminate; DELETE these two lines, once you have an implementation for -u in here */
    fprintf(stdout, "INCOMPLETE implementation, terminating program\n");
    return EXIT_FAILURE;
  }

  // -----------------------------------------------------------------------------
    /*generating the random master key*/
    initSeq();
    /*displaying the randomly generated sequence*/
    showSeq(theSeq);
  // +++++ main loop
  /*now, user enters guesses iteratively.*/
    while (!found) {
        /*counting user guesses*/
        attempts++;
        /*taking input from player as guess*/
        readString(arr);
        /*matching the player's guess with master key and calculating match: and Almost:*/
        b=countMatches(theSeq,arr);
        /*displaying the match result*/
        showMatches(0,theSeq,arr);
        /*setting the loop terminating condition*/
        if( match==LEN ){
            found=1;
        }
    }
    /*After successful match, displaying the details and End of Game*/
    if (found) {
        printf("SUCCESS after  %d iterations; secret sequence is %d %d %d\n",attempts,theSeq[0],theSeq[1],theSeq[2]);
        /*to pause standalone console*/
        printf("\nperss any charcter to exit");
        scanf("%c", &ch);
    }
    /*If user has failed to find the sequence*/
    else {
        printf("/nTry again/n");
    }
    return EXIT_SUCCESS;
}
  
